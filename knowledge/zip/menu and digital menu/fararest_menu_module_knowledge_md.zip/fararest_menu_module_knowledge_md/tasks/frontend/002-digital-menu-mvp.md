# Task: Build Digital Menu MVP

## Type

Frontend

## Required Context

- `knowledge/business/module-overview.md`
- `knowledge/business/business-rules.md`
- `knowledge/frontend/ux-principles.md`
- `knowledge/frontend/screens.md`
- `knowledge/product/prioritization.md`

## Goal

Build the first customer-facing digital menu experience.

## Scope

Implement only:

- public menu home
- category browsing
- item cards
- item detail
- item availability display
- simple cart UI
- dine-in/takeaway selection
- RTL mobile-first layout

## Out of Scope

- kiosk mode
- payment
- reservation
- loyalty
- AI recommendation
- Digital Signage
- advanced analytics

## Acceptance Criteria

- Customer can open menu by public link.
- Customer can browse categories.
- Customer can view item detail.
- Customer can add available item to cart.
- Unavailable items are clearly shown or disabled.
- Cart shows item price and total.
