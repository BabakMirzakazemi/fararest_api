# Task: Build Menu Management UI

## Type

Frontend

## Required Context

- `knowledge/business/business-rules.md`
- `knowledge/frontend/ux-principles.md`
- `knowledge/frontend/screens.md`

## Goal

Create the initial UI for managing categories and items.

## Scope

Implement only:

- menu dashboard skeleton
- category list/tree
- item list with table/card switch
- item create/edit wizard layout
- search and basic filters
- active/unavailable visual indicators

## Out of Scope

- public digital menu
- kiosk UI
- checkout
- payment
- advanced analytics
- A/B testing

## Acceptance Criteria

- User can see menu categories.
- User can see item list.
- User can search items.
- User can open create/edit item flow.
- Item form is step-based, not one long form.
- UI is RTL and Persian-friendly.
