# Fararest Menu Module - Agent Knowledge Pack

این پکیج از چهار سند Word مربوط به دو زیردامنه اصلی ساخته شده است:

1. مدیریت منو
2. منوی دیجیتال و کیوسک

هدف این خروجی، تبدیل مستندات بیزینسی و قابلیتی به ساختار Markdown قابل استفاده برای AI Agent است؛ به شکلی که Agent هم به بیزینس مسلط باشد و هم در هر تسک فقط در محدوده همان تسک عمل کند.

## ساختار پیشنهادی استفاده

```text
knowledge/
  business/   # همیشه خوانده شود
  backend/    # فقط برای تسک‌های backend
  frontend/   # فقط برای تسک‌های frontend
  product/    # برای تحلیل محصول، اولویت‌بندی و roadmap

tasks/
  backend/
  frontend/
  product/

agent.md
```

## قانون اصلی

Business context همیشه shared است، ولی backend و frontend فقط زمانی خوانده شوند که تسک مربوط به همان حوزه باشد.

## ترتیب پیشنهادی خواندن برای Agent

1. `agent.md`
2. `knowledge/business/module-overview.md`
3. `knowledge/business/business-rules.md`
4. `knowledge/business/glossary.md`
5. فایل‌های domain-specific بر اساس نوع تسک
6. task فعال از مسیر `tasks/`
