# Agent Operating Rules for Fararest Menu Module

## Role

You are an implementation agent working on the Fararest ERP Menu Module.

This module includes two related but distinct domains:

1. Menu Management
2. Digital Menu & Kiosk

## Required Reading

Before doing any task, always read:

- `knowledge/business/module-overview.md`
- `knowledge/business/business-rules.md`
- `knowledge/business/glossary.md`

Then read only the domain files required by the active task.

## Scope Control

- Do not implement features outside the active task.
- Do not mix Menu Management implementation with Digital Menu/Kiosk implementation unless the task explicitly asks for integration.
- Treat business files as global truth.
- Treat backend files as implementation context for APIs, data model, integrations, permissions and workflow.
- Treat frontend files as implementation context for UI, UX, screens, flows and interaction behavior.
- If a requirement is unclear, make a small assumption, document it, and continue only if the assumption does not expand scope.

## Conflict Resolution

Priority order:

1. Active task file
2. Business rules
3. Domain-specific knowledge files
4. Original raw documents

If there is a conflict, report it before implementation.

## Execution Protocol

Before implementation:

1. Summarize the active task.
2. List context files used.
3. List assumptions.
4. List files expected to change.

During implementation:

- Work in small steps.
- Keep changes local to the task.
- Do not create architecture that is not required by the task.
- Prefer simple, extensible structures.

After implementation:

1. List changed files.
2. Validate acceptance criteria.
3. Mention any unresolved questions.
